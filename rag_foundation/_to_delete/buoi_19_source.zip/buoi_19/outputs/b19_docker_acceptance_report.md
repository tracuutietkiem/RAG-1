# Buổi 19 — Docker & Local AI Acceptance Report (PROMPT 6)

| Hạng mục | Kết quả | Chi tiết |
|---|---|---|
| Ollama Server Connectivity | ❌ FAIL | KHÔNG kết nối được tới http://localhost:11434/api/tags (Khong ket noi duoc toi Ollama server (http://localhost:11434): HTTPConnectionPool(host='localhost', port=11434): Max retries exceeded with url: /api/tags (Caused by NewConnectionError("HTTPConnection(host='localhost', port=11434): Failed to establish a new connection: [Errno 111] Connection refused"))). Trong môi trường build (sandbox cloud) hiện tại KHÔNG thể cài Ollama thật (ollama.com và Docker Hub bị chặn ở tầng hạ tầng — xem README.md). Trên máy có Docker/Ollama thật, chạy `docker compose up -d` trước rồi chạy lại script này. |
| Local Model Availability (Qwen3:0.6b) | ❌ FAIL | Không kiểm tra được vì Ollama server offline (xem mục 1). |
| Dual Provider Switch (logic) | ✅ PASS | LLM_PROVIDER=ollama → gọi _call_ollama: True; LLM_PROVIDER=gemini → gọi _call_gemini: True. Định tuyến đúng theo biến môi trường (độc lập với việc server thật có online hay không). |
| Docker Compose Packaging | ✅ PASS | Dockerfile hợp lệ cú pháp cần thiết: True. docker-compose.yml: hợp lệ (docker compose config chạy không lỗi). |
| Local UC3 & UC4 Engines | ✅ PASS | UC3: 10 cặp (methods=['rule_no_confident_match', 'rule_numeric_floor_pct']). UC4: 16 mục (methods=['extractive_rule_based']). Đã dùng Qwen3:0.6b thật (llm_assisted_ollama): False. Trong lần chạy này hệ thống dùng fallback rule-based/extractive (Ollama offline trong môi trường build) — engine vẫn PASS vì fail-safe đúng thiết kế, nhưng CHƯA chứng minh được Qwen3:0.6b thật sinh nội dung. Chạy lại trên máy có Ollama thật để có bằng chứng đầy đủ. |
| Human Review & Audit Log | ✅ PASS | compliance_conflicts.csv: 10 dòng, NEEDS_HUMAN_REVIEW=đủ; audit_checklist_results.csv: 16 dòng, NEEDS_HUMAN_REVIEW=đủ; audit_log.jsonl: 11 dòng, 0 dòng nghi lộ secret |
| 6 bài Security & Local Guardrail Test | ✅ PASS | outputs/security_test_b19_report.md kết luận PASS. |

OLLAMA SERVER STATUS: FAIL
LOCAL MODEL QWEN3: FAIL
DOCKER CONTAINERIZATION: PASS
LOCAL COMPLIANCE ENGINES: PASS

LOCAL AI SYSTEM READY: NO

**Ghi chú quan trọng**: Nguyên nhân duy nhất khiến hệ thống chưa đạt `YES` là **Ollama server chưa chạy trong môi trường kiểm tra này** (không phải lỗi code/packaging — Docker packaging, dual-provider switch, RBAC, citation, human-review guardrail, audit log đều đã PASS). Môi trường build (sandbox cloud) không thể tải Ollama/Docker Hub do bị chặn mạng ở tầng hạ tầng (xem README.md mục 'Giới hạn môi trường sandbox'). **Trên máy học viên**: chạy `docker compose up -d` rồi `docker exec -it agribank-ollama-server ollama pull qwen3:0.6b`, sau đó chạy lại `python scripts/verify_b19_docker.py` để có kết quả `LOCAL AI SYSTEM READY: YES` với Qwen3:0.6b thật.
